# ex046 - Contagem Regressiva
# Fonte: Curso em Vídeo - desafio oficial (seu código)

from time import sleep 
print('-='*20)
print('-- CONTAGEM REGRESSIVA --')
print('-='*20)
for c in range(10,-1,-1):
    print(c)
    sleep(1)
print('BOOOMM!!!!')
