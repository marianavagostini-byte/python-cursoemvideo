# ex003 - Somando Dois Números
# Fonte: Curso em Vídeo - desafio oficial (seu código)

n1 = int(input('Digite um valor: '))
n2 = int(input('Digite outro valor: '))
s = n1 + n2
print('A soma entre {} e {} é igual a {}!'.format(n1, n2, s))
