# ex016 - Quebrando um Número
# Fonte: Curso em Vídeo - desafio oficial (complementado)

from math import trunc
num = float(input('Digite um valor: '))
print('O valor digitado foi {} e a sua porção inteira é {}'.format(num, trunc(num)))
